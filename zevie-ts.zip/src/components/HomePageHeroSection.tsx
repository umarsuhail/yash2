import React from 'react'
import evCar from '../assets/images/ev.jpeg'
const HomePageHeroSection = () => {
    return (
        <div>
            <img src={evCar} alt="ev"></img>
        </div>
    )
}
export default HomePageHeroSection
