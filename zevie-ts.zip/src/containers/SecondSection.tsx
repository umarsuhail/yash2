import React from 'react'

const SecondSection = () => {
    return (
        <div>
            
        </div>
    )
}
export default SecondSection;